import json
import pandas

def api1(conn, list):

    cur = conn.cursor()

    if list is not None:
        cur.execute("""
        SELECT CD.ID, CD.CHARTTIME, CD.VALUENUM,
            CD.ERROR, CD.WARNING, CD.STOPPED,
            OT.NAME, RS.NAME, UOM.NAME

        FROM CHART_DATA CD
        LEFT JOIN OBSERVATION_TYPE OT
        ON CD.OBSERVATION_TYPE_ID = OT.ID
        LEFT JOIN RESULT_STATUS RS
        ON CD.RESULT_STATUS_ID = RS.ID
        LEFT JOIN UNIT_OF_MEASURE UOM
        ON CD.UNIT_OF_MEASURE_ID = UOM.ID

        WHERE CD.ID IN ("""+list+")"
        )
    row_headers=[x[0] for x in cur.description]
    rows = cur.fetchall()
    json_data = []
    for result in rows:
        json_data.append(dict(zip(row_headers,result)))
    return json.dumps(json_data)

def api2(conn):

    cur = conn.cursor()

    cur.execute("""

    SELECT OT.NAME OBSERVATION_NAME, UOM.NAME UNIT_OF_MEASURE_NAME, COUNT(ICUSTAY_ID) ADMISSIONS,
     MIN(VALUENUM) OVER(PARTITION BY OT.NAME, UOM.NAME), MAX(VALUENUM) OVER(PARTITION BY OT.NAME, UOM.NAME)

    FROM CHART_DATA CD
    LEFT JOIN OBSERVATION_TYPE OT
    ON CD.OBSERVATION_TYPE_ID = OT.ID
    LEFT JOIN UNIT_OF_MEASURE UOM
    ON CD.UNIT_OF_MEASURE_ID = UOM.ID
    LEFT JOIN RESULT_STATUS RS
    ON CD.RESULT_STATUS_ID = RS.ID

    WHERE ERROR <> '1'
    AND WARNING <> '1'

    GROUP BY OT.NAME,UOM.NAME

    """
    )
    row_headers=[x[0] for x in cur.description]
    rows = cur.fetchall()
    json_data = []
    for result in rows:
        json_data.append(dict(zip(row_headers,result)))
    return json.dumps(json_data)

def api3(conn):

    df = pandas.read_sql_query("""

    SELECT OT.NAME OBSERVATION_NAME, UOM.NAME UNIT_OF_MEASURE_NAME, ICUSTAY_ID, VALUENUM

    FROM CHART_DATA CD
    LEFT JOIN OBSERVATION_TYPE OT
    ON CD.OBSERVATION_TYPE_ID = OT.ID
    LEFT JOIN UNIT_OF_MEASURE UOM
    ON CD.UNIT_OF_MEASURE_ID = UOM.ID
    LEFT JOIN RESULT_STATUS RS
    ON CD.RESULT_STATUS_ID = RS.ID

    WHERE ERROR <> '1'
    AND WARNING <> '1'

    GROUP BY OT.NAME,UOM.NAME

    """,conn
    )


    res = df.groupby(["OBSERVATION_NAME","UNIT_OF_MEASURE_NAME"]).count()
    res = res.assign(Max = df.groupby(["OBSERVATION_NAME","UNIT_OF_MEASURE_NAME"])["VALUENUM"].max())
    res = res.assign(Min = df.groupby(["OBSERVATION_NAME","UNIT_OF_MEASURE_NAME"])["VALUENUM"].min())

    return(res.to_json())
