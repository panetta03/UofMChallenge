from flask import Flask, request
from sqconnection import create_connection
from apis import api1,api2,api3
import os

database = "/code/randomized_chart_data.sqlite"
 
app=Flask(__name__)
 
 
 
@app.route("/",methods=['GET'])
def index():

    return '''Available Routes:<br>
            /api1 requires single value or comma separated list<br>
            /api2 Summary returned in json<br>
            /api3 Summary return in json using pandas
            '''


@app.route("/api1",methods=['GET'])
def getIds():    

    # create a database connection
    ids = request.args['ids'] 
    conn = create_connection(database)
    with conn:

        resp = api1(conn, ids)
    return resp

@app.route("/api2",methods=['GET'])
def getSummary():    

    # create a database connection
    conn = create_connection(database)
    with conn:

        resp =  api2(conn)

    return resp

@app.route("/api3",methods=['GET'])
def getSummaryPandas():    

    # create a database connection
    conn = create_connection(database)
    with conn:

        resp = api3(conn)
    return resp
 
 
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0', port=9007)