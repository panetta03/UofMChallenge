I implemented the APIs in python using Flask. I created three endpoints for each Api: api1, api2, api3.

Each endpoint can be called from the browser using localhost:8000/<api> 

Given that I used flask I used the root index as means to show the example routes.

In python I chose to separate the code into three python scripts:

-The first is a script to create a sqllite connection
-The second stores all the APIs
-The third is the flask app

I chose to design it like this to avoid repeating myself. 

Things I didn't choose to implement given timing constraints was unit testing.



